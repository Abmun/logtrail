hashmodrt=abs(hash(flow.getVariable("companyid")))% 7;
flow.setVariable("hashmodroute",hashmodrt);