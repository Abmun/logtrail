cookie = flow.getVariable("response.header.Set-Cookie")



JSESSIONID = None
if cookie:
  for part in  cookie.split(';'):
    key, separator, value = part.strip().partition('=')
    if 'JSESSIONID' == key:
      JSESSIONID = value
      break
        
if JSESSIONID:
	flow.setVariable("JSESSIONID", JSESSIONID)