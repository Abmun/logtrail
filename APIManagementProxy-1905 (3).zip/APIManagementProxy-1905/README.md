
**Description of Contents**

The default directory structure of APIGEE proxy for successfactors

```
root
├───general_proxy
│   ├───policies
│   ├───proxies
│   ├───resources
│   │   └───jsc
│   └───targets
├───odata_proxy
│   ├───policies
│   ├───proxies
│   ├───resources
│   │   ├───jsc
│   │   └───py
│   └───targets
├───sfapi_proxy
│   ├───policies
│   ├───proxies
│   ├───resources
│   │   └───jsc
│   └───targets
└───wfa_proxy
    ├───policies
    ├───proxies
    ├───resources
    │   └───jsc
    └───targets
```	
	
**sfapi_proxy:**
APIGEE proxy for all API calls with endpoint containing **/sfapi/v1/**

**odata_proxy:**
APIGEE proxy for all API calls with endpoint containing **/odata/v2/**

**general_proxy:**
APIGEE proxy for all API calls with endpoints except sf_api and odata

**wfa_proxy:**
APIGEE proxy for all WFA Odata API calls with endpoint containing **/odatav2/analytics/v1/**



**Reference:**
https://confluence.successfactors.com/pages/viewpage.action?spaceKey=SSIO&title=API+Management 

**API Proxy Management Team DL:**

DL HCM Ops Platform Integration API Mgmt (External) <DL_561D18B57BCF845C43000082@exchange.sap.corp> 


Release Notes:

1902 Release - No changes to APIGEE policy

1905 Release

IOE-370 # ODATA and SFAPI Cookie path changes in APIGEEE Policy.
IOE-10  # Implement new BixZ API health check based routing in APIGEE Policy



